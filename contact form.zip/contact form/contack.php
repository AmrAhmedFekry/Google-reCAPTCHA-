<?php
if (isset($_POST['g-recaptcha-response']) && $_POST['g-recaptcha-response']) {

// Your scret code You can get you just go to this url
// https://www.google.com/recaptcha/admin#list
// just Register a new site and You can got it 	

$secret = "";	
$ip = $_SERVER['REMOTE_ADDR'];
$captcha = $_POST['g-recaptcha-response'];
$rsp = file_get_contents( "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha&remoteip=$ip");
$array = json_decode($rsp,TRUE);

}



?>